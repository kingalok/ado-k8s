# Timeline & Milestones

- Week 1–2: Discovery & inventory, repo bootstrapping, pilot namespace
- Week 3–4: Pilot pools (S/M), migrate 2–3 pipelines, validate KEDA
- Week 5–6: Expand pools (M/L), blue/green release procedure
- Week 7–8: Region-by-region cutover, VM decom, post-mortem & docs
