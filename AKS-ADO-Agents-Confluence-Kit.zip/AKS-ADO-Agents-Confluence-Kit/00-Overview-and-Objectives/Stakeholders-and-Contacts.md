# Stakeholders & Contacts

| Role | Name | Team | Responsibilities |
|------|------|------|------------------|
| Product Owner | TBD | PG Platform | KPIs, priorities, approvals |
| Platform Lead | TBD | AKS Platform | Namespace, policies, scaling |
| SRE Lead | TBD | SRE | Runbooks, on-call, releases |
| Security | TBD | Sec/GRC | Policies, audits, approvals |
| DevSecOps | TBD | DevSecOps | Scanning, signing, SBOM |
