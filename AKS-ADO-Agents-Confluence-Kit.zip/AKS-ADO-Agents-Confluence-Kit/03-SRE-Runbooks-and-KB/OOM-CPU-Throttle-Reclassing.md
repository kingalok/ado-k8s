# OOM/CPU Throttle & Re-classing

- Inspect pod OOMKilled and throttling metrics
- Promote workload to M or L class; adjust requests/limits
- Validate VPA recommendations; update values.yaml
