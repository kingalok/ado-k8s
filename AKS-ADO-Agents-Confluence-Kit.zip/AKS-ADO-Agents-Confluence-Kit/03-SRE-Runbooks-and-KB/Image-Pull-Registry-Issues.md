# Image Pull / Registry Issues

- Check image URI, tag/digest, replica availability
- Node image cache pressure; back-off events
- Admission signature verification failures
