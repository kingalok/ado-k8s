# Network/Proxy/DNS Issues

- NO_PROXY and proxy variables set?
- Outbound firewall allowlist; TLS interception certs
- CoreDNS latency; node-level DNS caching
