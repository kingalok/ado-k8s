# KEDA/HPA/Autoscaler Troubleshooting

- ScaledObject status; pending jobs metric live?
- HPA target and min/max replicas; cooldown
- Cluster Autoscaler activity and node quotas
