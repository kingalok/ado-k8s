# Agent Registration Failures

**Checklist**
- PAT validity/scope, Secret Store mount present
- Egress to dev.azure.com and time sync
- Agent pool name, org URL, DNS resolution
- Pod identity and ServiceAccount permissions
