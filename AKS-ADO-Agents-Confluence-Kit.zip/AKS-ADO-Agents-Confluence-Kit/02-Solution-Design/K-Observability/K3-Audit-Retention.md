# K3 Audit & Retention – kubernetes events, ADO logs, retention
