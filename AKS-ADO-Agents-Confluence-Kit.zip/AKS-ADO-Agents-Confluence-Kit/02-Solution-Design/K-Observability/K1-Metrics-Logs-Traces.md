# K1 Metrics, Logs, Traces – KEDA, pod restarts/OOM, image pulls
