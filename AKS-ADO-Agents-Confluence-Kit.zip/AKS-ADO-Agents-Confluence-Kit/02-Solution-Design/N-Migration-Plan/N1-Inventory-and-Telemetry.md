# N1 Inventory & Telemetry Capture – scripts and data model
