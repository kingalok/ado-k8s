# E2 Azure Policy / Gatekeeper rules – list enforced constraints and exemptions
