# E3 NetworkPolicies – deny-all egress + allowlist dev.azure.com, registry, NTP
