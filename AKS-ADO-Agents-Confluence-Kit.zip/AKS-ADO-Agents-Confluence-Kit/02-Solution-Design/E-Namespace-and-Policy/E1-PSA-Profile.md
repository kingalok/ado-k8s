# E1 PSA Profile (Baseline/Restricted)

- runAsNonRoot: true
- allowPrivilegeEscalation: false
- readOnlyRootFilesystem: true
- drop capabilities: ALL
