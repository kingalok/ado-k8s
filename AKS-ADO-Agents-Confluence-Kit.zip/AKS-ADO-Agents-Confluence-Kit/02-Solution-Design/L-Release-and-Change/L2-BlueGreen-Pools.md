# L2 Blue/Green Pools & Rollback – dual pools + pool switch procedure
