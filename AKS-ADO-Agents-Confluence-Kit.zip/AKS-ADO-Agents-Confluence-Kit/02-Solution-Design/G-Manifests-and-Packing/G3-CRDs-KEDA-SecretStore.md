# G3 CRDs (KEDA, Secret Store) & Versioning – CRD versions and upgrade steps
