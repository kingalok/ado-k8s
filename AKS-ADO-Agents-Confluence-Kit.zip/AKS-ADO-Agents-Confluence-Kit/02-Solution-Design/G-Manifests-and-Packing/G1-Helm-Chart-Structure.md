# G1 Helm Chart Structure & values.yaml

- templates/: Deployment, ServiceAccount, RBAC, ScaledObject
- values: pool name, image, resources, env, nodeSelector/tolerations
