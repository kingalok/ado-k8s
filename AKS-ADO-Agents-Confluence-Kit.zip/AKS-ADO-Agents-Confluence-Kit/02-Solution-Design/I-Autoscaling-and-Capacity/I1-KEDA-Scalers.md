# I1 KEDA Scalers per Pool – pending jobs threshold, cooldown period
