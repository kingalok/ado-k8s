# I3 VPA/Goldilocks & Right-Sizing – review cadence and actions
