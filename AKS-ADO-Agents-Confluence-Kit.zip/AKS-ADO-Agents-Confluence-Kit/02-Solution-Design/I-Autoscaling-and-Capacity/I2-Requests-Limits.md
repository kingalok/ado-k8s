# I2 Requests/Limits (S/M/L classes) – start S: 0.5/1Gi, M: 2/4Gi, L: 4/8–16Gi; tune via telemetry
