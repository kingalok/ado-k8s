# D3 Data/Identity Flows – (embed draw.io)

- OIDC federation, PAT registration, Key Vault via CSI driver
