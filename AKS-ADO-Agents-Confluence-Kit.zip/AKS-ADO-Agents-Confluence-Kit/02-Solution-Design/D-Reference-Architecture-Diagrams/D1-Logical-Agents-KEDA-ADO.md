# D1 Logical Diagram – (embed draw.io)

- Agents, Pools, KEDA ScaledObjects, ADO service
