# D2 Physical/Network Blueprint – (embed draw.io)

- AKS cluster, nodepools, egress path, NAT/Firewall, registries
