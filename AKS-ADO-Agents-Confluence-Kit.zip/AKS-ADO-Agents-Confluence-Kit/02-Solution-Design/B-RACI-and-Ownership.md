# RACI & Ownership

| Area | PG Platform | SRE | AKS Platform | Security |
|------|-------------|-----|--------------|----------|
| Image build/sign | A/R | C | I | C |
| Chart/Manifests | A/R | C | I | C |
| Namespace & policy | C | C | A/R | C |
| Deploy & promo | A | R | C | C |
| Observability | A | R | C | C |
