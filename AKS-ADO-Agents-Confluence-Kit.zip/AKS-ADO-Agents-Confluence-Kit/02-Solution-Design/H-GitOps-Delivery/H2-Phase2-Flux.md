# H2 Phase-2: Flux

- Source/Helm/Kustomize controllers; HelmRelease per pool
- Image automation (optional) to bump tags in Git
- Flagger for progressive delivery (optional)
