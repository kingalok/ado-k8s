# H3 Image Automation & Promotion – tags/branches, region waves, SoD
