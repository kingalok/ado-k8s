# H1 Phase-1: Helm via ADO

- ADO service connection to cluster
- `helm upgrade --install` from chart repo + values per region
- Approvals/gates in ADO Environments
