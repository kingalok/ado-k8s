# M1 Smoke & Functional Tests – representative pipelines
