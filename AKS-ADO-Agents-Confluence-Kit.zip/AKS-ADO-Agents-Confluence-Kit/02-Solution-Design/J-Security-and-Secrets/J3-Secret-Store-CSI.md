# J3 Secret Store CSI / Key Vault – mounting secrets and rotation patterns
