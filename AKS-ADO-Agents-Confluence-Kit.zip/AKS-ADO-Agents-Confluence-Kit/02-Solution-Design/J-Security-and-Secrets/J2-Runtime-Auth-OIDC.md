# J2 Runtime Auth via OIDC/Workload Identity – service connections
