# J1 Agent Registration (short-lived PAT) – rotation and Secret Store usage
