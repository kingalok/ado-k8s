# O DR/BCP & Multi-Region – routing jobs, replica registries, failover steps
