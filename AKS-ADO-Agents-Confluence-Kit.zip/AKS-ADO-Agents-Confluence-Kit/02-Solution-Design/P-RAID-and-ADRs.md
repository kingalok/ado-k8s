# Risks, Issues & Decisions (RAID + ADRs) – templates for decisions
