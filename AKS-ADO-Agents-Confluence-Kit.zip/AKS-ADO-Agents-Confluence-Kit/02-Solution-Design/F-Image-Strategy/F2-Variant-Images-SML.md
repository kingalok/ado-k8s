# F2 Variant Images (S/M/L) – adjust tool caches and JVM/python/node as needed
