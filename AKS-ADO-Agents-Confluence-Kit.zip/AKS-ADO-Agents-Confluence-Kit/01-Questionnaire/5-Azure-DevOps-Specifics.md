# 5. Azure DevOps Specifics (Pools, PAT, OIDC, Toolchain)
- Pools per region/size? Ephemeral vs long-lived agents?
- PAT rotation owner? Agent self-update policy?
- Toolchain versions (psql, pg_dump, pgBackRest, az, etc.)
