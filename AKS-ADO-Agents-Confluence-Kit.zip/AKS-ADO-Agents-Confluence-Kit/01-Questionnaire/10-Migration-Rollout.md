# 10. Migration & Rollout
- Pilot region, exit criteria, dual-run period, comms plan
