# 3.3 Add-ons (KEDA/Flux/Secret Store), Readiness
- Is KEDA supported? Flux roadmap? Secret Store CSI/Key Vault?
