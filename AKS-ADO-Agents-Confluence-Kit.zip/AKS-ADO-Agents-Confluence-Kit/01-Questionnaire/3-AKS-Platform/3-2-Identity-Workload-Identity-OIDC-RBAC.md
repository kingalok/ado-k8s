# 3.2 Identity (AKS Workload Identity/OIDC), RBAC
- Is OIDC enabled? Process for federated identities?
- Namespace RBAC for SRE (write) vs audit (read-only)
