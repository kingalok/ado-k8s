# 3.4 Compute & Scaling (Nodepools, Cluster Autoscaler, VPA)
- Dedicated tainted pools? Max nodes? CA policies? VPA allowed?
