# 3.5 Networking & Egress (NAT, Proxy, DNS)
- Outbound model? Egress allowlist (dev.azure.com, registry)?
- Corporate proxy/CA? DNS caching?
