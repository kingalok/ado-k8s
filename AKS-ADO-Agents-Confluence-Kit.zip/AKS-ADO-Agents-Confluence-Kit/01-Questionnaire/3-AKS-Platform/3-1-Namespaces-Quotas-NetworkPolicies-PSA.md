# 3.1 Namespaces, Quotas, NetworkPolicies, PSA
- Default quotas/LimitRange? Baseline/Restricted PSA? Azure Policy?
- Admission controllers (Gatekeeper/Kyverno)? Exceptions process?
- Default NetworkPolicies (deny-all egress/ingress)?
