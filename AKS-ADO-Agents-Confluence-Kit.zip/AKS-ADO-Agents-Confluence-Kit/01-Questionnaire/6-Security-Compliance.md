# 6. Security & Compliance
- PSA level; runAsNonRoot; read-only FS; capability drop list
- Egress policy; CVSS gates; audit requirements
