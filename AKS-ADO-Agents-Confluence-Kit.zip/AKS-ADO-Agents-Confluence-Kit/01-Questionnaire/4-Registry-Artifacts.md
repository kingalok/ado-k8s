# 4. Registry & Artifacts (ACR/Nexus, Geo-replication)
- Geo-replication/replication? Helm OCI or Nexus Helm repo?
- Image signing, SBOM format, admission policy?
