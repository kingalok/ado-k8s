# 7. Operations / SRE
- SLOs; paging thresholds; runbooks; kubectl access model
- Release process (blue/green), rollback, region promotions
