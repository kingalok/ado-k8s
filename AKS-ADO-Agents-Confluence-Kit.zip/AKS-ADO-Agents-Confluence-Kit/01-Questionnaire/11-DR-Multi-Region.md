# 11. DR & Multi-Region Resilience
- Route jobs across regions? Registry/chart replicas active/active?
