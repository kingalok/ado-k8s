# 12. Documentation & Training
- Required KBs, diagrams, training sessions (KEDA/Flux, OIDC)
