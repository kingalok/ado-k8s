# 2. Current State Inventory (VM Agents & Pipelines)
- VM agents by region/pool/size/tools; pipeline→pool mapping
- 30–90d telemetry: durations, concurrency, CPU/RAM/IO by job type
- Top failure modes (missing packages, disk, network, PAT)
- Heavy jobs (backup/restore, pg_dump/restore)
