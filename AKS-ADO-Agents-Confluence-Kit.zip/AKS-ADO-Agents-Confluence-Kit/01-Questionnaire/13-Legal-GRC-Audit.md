# 13. Legal/GRC & Audit
- Access reviews, SoD, evidence collection, audit cadence
