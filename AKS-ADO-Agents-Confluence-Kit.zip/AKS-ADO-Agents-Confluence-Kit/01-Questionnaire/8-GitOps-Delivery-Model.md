# 8. GitOps / Delivery Model
- Flux controllers (Source/Helm/Kustomize/Image Automation)?
- If no Flux: ADO Helm deployments allowed? CRDs?
