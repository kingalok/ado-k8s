# 9. Cost & FinOps
- Chargeback/showback, egress costs, burst headroom policies
