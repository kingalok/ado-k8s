# 1. Business & Program
- Goals/KPIs? Queue wait time, success rate, MTTR, cost/100 jobs?
- Regions in scope now vs next 12 months?
- Availability targets, maintenance windows, freeze periods?
- Ownership and PR/approval flow for image/chart/env?
