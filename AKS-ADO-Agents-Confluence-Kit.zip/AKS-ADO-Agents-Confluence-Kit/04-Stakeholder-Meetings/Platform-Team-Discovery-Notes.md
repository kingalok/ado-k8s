# Platform Team – Discovery Notes

- Questions, decisions, owners, dates
