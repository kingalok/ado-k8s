# SRE Team – Discovery Notes

- Pain points, current SOPs, telemetry sources
