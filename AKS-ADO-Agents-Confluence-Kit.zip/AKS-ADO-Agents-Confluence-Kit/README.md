# Confluence Kit


AKS-based Azure DevOps Agents (Confluence Kit)
- 00-Overview-and-Objectives/
- 01-Questionnaire/
- 02-Solution-Design/
- 03-SRE-Runbooks-and-KB/
- 04-Stakeholder-Meetings/
- 05-Templates-and-Samples/


Import these pages into Confluence (one page per file).
