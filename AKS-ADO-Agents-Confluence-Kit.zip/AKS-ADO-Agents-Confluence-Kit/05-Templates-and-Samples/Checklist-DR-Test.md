# DR Test Checklist

- [ ] Simulate regional outage; route workloads to secondary
- [ ] Registry replica tested; image pulls from secondary succeed
- [ ] RTO/RPO validated; runbook updated
