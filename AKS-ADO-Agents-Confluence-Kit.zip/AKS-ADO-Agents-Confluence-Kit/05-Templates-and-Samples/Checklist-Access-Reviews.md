# Access Reviews

- [ ] Namespace RBAC least privilege validated
- [ ] Service connections via OIDC only
- [ ] PAT rotation schedule executed and logged
