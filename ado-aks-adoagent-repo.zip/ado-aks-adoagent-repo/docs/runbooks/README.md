# Runbooks
- Registration failures
- Image pull backoff
- KEDA not scaling / HPA issues
- OOMKilled / CPU throttling
- Proxy/DNS/CA issues
